from PodSixNet.Channel import Channel
from PodSixNet.Server import Server
from time import sleep

class ClientChannel(Channel):
    def __init__(self, *args, **kwargs):
        Channel.__init__(self, *args, **kwargs)
        self.num = 0
        
    def Close(self):
        self._server.del_channel(self)
        
    def Network_sendhero(self, data):
        self._server.send_hero(int(not self.num), data)
        
    def Network_sendwinner(self, data):
        self._server.send_winner(int(not self.num), data)
    
    
class MyServer(Server):
    channelClass = ClientChannel
    def __init__(self, *args, **kwargs):
        Server.__init__(self, *args, **kwargs)
        self.channels_num = 0
        self.chls = [None, None]

        
    def Connected(self, channel, addr):
        if self.channels_num == 0 or self.channels_num == 1:
            print 'New connection:', channel
            if self.chls[0] == None:
                channel.num = 0
            else:
                channel.num = 1
            self.chls[channel.num] = channel
            self.channels_num += 1
            if self.channels_num == 2:
                #print self.chls
                self.chls[0].Send({'action': 'startgame'})
                self.chls[1].Send({'action': 'startgame'})
                
        else:
            print 'Connection refused. Two players have already connected.'
    
    def del_channel(self, channel):
        print 'Delete channel:', channel
        self.chls[channel.num] = None
        self.channels_num -= 1
        if self.channels_num <= 0:
            self.channels_num = 0
        for ch in self.chls:
            if ch != None:
                ch.Send({'action': 'endgame'})
        
    def send_hero(self, player_id, data):
        if self.chls[0] != None and self.chls[1] != None:
            self.chls[player_id].Send({'action': 'gethero',
                                        'left': data['left'],
                                        'top': data['top'],
                                        'cur_frame': data['cur_frame']})
            
    def send_winner(self, player_id, data):
        if self.chls[0] != None and self.chls[1] != None:
            self.chls[player_id].Send({'action': 'getwinner'})
        

delta = 1.0/180
#server = MyServer(localaddr=('0.0.0.0', int(8000)))
server = MyServer(localaddr=('localhost', int(8000)))
while True:
    server.Pump()
    sleep(delta)
    
