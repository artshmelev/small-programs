import sys
import pygame
import tmxreader, helperspygame
from pygame.locals import *
from PodSixNet.Connection import ConnectionListener, connection

from player import Player, IMGS
from blocks import *
from camera import Camera

FPS = 60
WWIDTH = 800
WHEIGHT = 700
SWHEIGHT = WHEIGHT/2 - 5

BRIGHTBLUE = (0, 170, 255)

BG_COLOR = BRIGHTBLUE

entities = pygame.sprite.Group()
monsters = pygame.sprite.Group()
platforms = []

class MyNetworkListener(ConnectionListener):        
    def Network_connected(self, data):
        print 'connected to the server'
        
    def Network_error(self, data):
        print 'error:', data['error'][1]
        
    def Network_disconnected(self, data):
        print 'disconnected from the server'
        
    def Network_gethero(self, data):
        global hero1
        hero1.rect.x = data['left']
        hero1.rect.y = data['top']
        hero1.cur_frame = data['cur_frame']

def main():
    global SCREEN, FPSCLOCK, BASICFONT
    pygame.init()
    FPSCLOCK = pygame.time.Clock()
    SCREEN = pygame.display.set_mode((WWIDTH, WHEIGHT))
    pygame.display.set_caption('Platformer Game')
    BASICFONT = pygame.font.Font('freesansbold.ttf', 32)
    
    run_game()


def run_game():
    global hero1
    listener = MyNetworkListener()
    listener.Connect(('93.175.7.193', 8000))
    renderer0 = helperspygame.RendererPygame()
    renderer1 = helperspygame.RendererPygame()
    
    screen0 = pygame.Surface((WWIDTH, SWHEIGHT))
    screen1 = pygame.Surface((WWIDTH, SWHEIGHT))
    move_left = move_right = False
    move_up = False
    
    player_x, player_y, total_level_w, total_level_h, sprite_layers = \
                                                        load_level('map01.tmx')
    hero0 = Player(player_x, player_y)
    hero1 = Player(player_x, player_y)

    entities.add(hero0)

    camera0 = Camera(camera_configure, total_level_w, total_level_h)
    camera1 = Camera(camera_configure, total_level_w, total_level_h)

    while True:
        connection.Pump()
        listener.Pump()
        for event in pygame.event.get():
            if event.type == QUIT:
                terminate()
            elif event.type == KEYDOWN:
                if event.key == K_LEFT:
                    move_left = True
                elif event.key == K_RIGHT:
                    move_right = True
                elif event.key == K_UP:
                    move_up = True
            elif event.type == KEYUP:
                if event.key == K_LEFT:
                    move_left = False
                elif event.key == K_RIGHT:
                    move_right = False
                elif event.key == K_UP:
                    move_up = False      
                
        SCREEN.fill((255, 0, 0))
        screen0.fill(BG_COLOR)
        screen1.fill(BG_COLOR)

        hero0.update(move_left, move_right, move_up, platforms)
        connection.Send({'action': 'sendhero',
                         'left': hero0.rect.x, 'top': hero0.rect.y,
                         'cur_frame': hero0.cur_frame})
        camera0.update(hero0)
        camera1.update(hero1)
                
        center_offset0 = camera0.reverse((WWIDTH/2, SWHEIGHT/2))
        center_offset1 = camera1.reverse((WWIDTH/2, SWHEIGHT/2))
        renderer0.set_camera_position_and_size(center_offset0[0],
                                               center_offset0[1],
                                               WWIDTH, SWHEIGHT, 'center')
        renderer1.set_camera_position_and_size(center_offset1[0],
                                               center_offset1[1],
                                               WWIDTH, SWHEIGHT, 'center')
        
        for layer in sprite_layers:
            if not layer.is_object_group:
                renderer0.render_layer(screen0, layer)
                renderer1.render_layer(screen1, layer)
        for e in entities:
            screen0.blit(IMGS[hero0.cur_frame], camera0.apply(e))
        screen1.blit(IMGS[hero1.cur_frame], camera1.apply(hero1))
        
        SCREEN.blit(screen0, (0, 0))
        SCREEN.blit(screen1, (0, SWHEIGHT + 10))
        
        pygame.display.update()
        FPSCLOCK.tick(FPS)


def camera_configure(camera, target_rect):
    l, t, _, _ = target_rect
    _, _, w, h = camera
    l, t = -l + WWIDTH/2, -t + SWHEIGHT/2
    
    l = min(0, l)
    l = max(-camera.width + WWIDTH, l)
    t = max(-camera.height + SWHEIGHT, t)
    t = min(0, t)
    
    return pygame.Rect(l, t, w, h)


def load_level(name):
    world_map = tmxreader.TileMapParser().parse_decode(name)
    resources = helperspygame.ResourceLoaderPygame()
    resources.load(world_map)
    
    sprite_layers = helperspygame.get_layers_from_map(resources)
    platforms_layer = sprite_layers[1]
    
    for row in xrange(0, platforms_layer.num_tiles_x):
        for col in xrange(0, platforms_layer.num_tiles_y):
            if platforms_layer.content2D[col][row] is not None:
                pf = Platform(row*PLATFORM_WIDTH, col*PLATFORM_HEIGHT)
                platforms.append(pf)
                
    monsters_layer = sprite_layers[2]
    player_x = player_y = None
    for monster in monsters_layer.objects:
        x = monster.x
        y = monster.y
        if monster.name == 'Player':
            player_x = x
            player_y = y - PLATFORM_HEIGHT
            
    total_level_w = platforms_layer.num_tiles_x * PLATFORM_WIDTH
    total_level_h = platforms_layer.num_tiles_y * PLATFORM_HEIGHT
    return (player_x, player_y, total_level_w, total_level_h, sprite_layers)


def terminate():
    pygame.quit()
    sys.exit()


if __name__ == '__main__':
    main()
    